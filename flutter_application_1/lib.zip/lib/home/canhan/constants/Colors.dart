import 'package:flutter/material.dart';

const Color tdRed = Color(0xFFE57373);
const Color tdBlue = Color(0xFF64B5F6);

const Color tdBlack = Color(0xFF212121);
const Color tdGray = Color.fromARGB(255, 41, 41, 41);

const Color tdBGColor = Color(0xFFF5F5F5);